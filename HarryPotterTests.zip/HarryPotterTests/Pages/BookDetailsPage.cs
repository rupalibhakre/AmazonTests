﻿using System;
using System.Collections.Generic;
using System.Text;
using HarryPotterTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace HarryPotterTests.Pages
{
    public class BookDetailsPage
    {
        IWebDriver driver;

     

        public BookDetailsPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebElement BookTitle => driver.FindElement(By.Id("productTitle"));
        public IWebElement PaperBackType => driver.FindElement(By.XPath("//*[@id='a-autoid-5-announce']/span[1]"));
        public IWebElement BookPrice => driver.FindElement(By.XPath("//*[@id='a-autoid-5']"));
        public IWebElement AddToBasketButton => driver.FindElement(By.Id("add-to-cart-button"));


        public string TitleIsDisplayed()
        {
            string text;
            text = BookTitle.Text;
            return text;
        }

        public string TypeIsPaperBack()
        {
            string text;
            text = PaperBackType.Text;
            return text;
        }

        public string PriceIsDisplayed()
        {
            return BookPrice.Text;
        }

        public void ClickAddToBasketButton()
        {
            AddToBasketButton.Click();
        }


    }
}
