﻿using System;
using System.Collections.Generic;
using System.Text;
using HarryPotterTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace HarryPotterTests.Pages
{
    public class AddBasketPage
    {
        IWebDriver driver;

        public AddBasketPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebElement Notification => driver.FindElement(By.XPath("//*[@id='huc-v2-order-row-confirm-text']/h1"));

        public IWebElement BasketCount => driver.FindElement(By.Id("nav-cart-count"));

        public IWebElement BasketLink => driver.FindElement(By.Id("nav-cart-text-container"));
       

        public string NotificationIsDisplayed()
        {
            string text;
            text = Notification.Text;
            return text;
        }


        public string QuantityIsDisplayed()
        {
            
            return BasketCount.Text;
            
        }

        public void ClickEditBasket()
        {
            BasketLink.Click();
        }




    }
}
