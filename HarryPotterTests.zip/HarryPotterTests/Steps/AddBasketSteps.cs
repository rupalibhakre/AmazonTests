﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarryPotterTests.Hooks;
using HarryPotterTests.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;


namespace HarryPotterTests.Steps
{
    [Binding, Scope(Tag = "UI")]
    public class AddBasketSteps
    {
        private HomePage HomePage => new HomePage(SpecflowHooks.driver);

        private BooksPage BooksPage => new BooksPage(SpecflowHooks.driver);

        private BookDetailsPage BookDetailsPage => new BookDetailsPage(SpecflowHooks.driver);

        private AddBasketPage AddBasketPage => new AddBasketPage(SpecflowHooks.driver);

       
        [When(@"click on Add to basket button")]
        public void WhenClickOnAddToBasketButton()
        {
            BookDetailsPage.ClickAddToBasketButton();
        }

        [Then(@"the notification is displayed ""(.*)""")]
        public void ThenTheNotificationIsDisplayed(string expectedNotification)
        {
            Assert.AreEqual(expectedNotification, AddBasketPage.NotificationIsDisplayed());
        }

        [Then(@"there is (.*) item in the basket")]
        public void ThenThereIsItemInTheBasket(string expectedQuantity)
        {
            Assert.AreEqual(expectedQuantity, AddBasketPage.QuantityIsDisplayed());
        }



    }
}
