﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarryPotterTests.Hooks;
using HarryPotterTests.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;


namespace HarryPotterTests.Steps
{
    [Binding]
    public class BookDetailSteps
    {
        
        private HomePage HomePage => new HomePage(SpecflowHooks.driver);

        private BooksPage BooksPage => new BooksPage(SpecflowHooks.driver);

        private BookDetailsPage BookDetailsPage => new BookDetailsPage(SpecflowHooks.driver);


        [When(@"they Search for the Harry Potter and the Cursed Child")]
        public void WhenTheySearchForTheHarryPotterAndTheCursedChild()
        {
            HomePage.ClickAcceptLink();
            HomePage.ClickBooksLink();
            BooksPage.EnterBookName();
            BooksPage.ClickSearchIcon();
            BooksPage.WaitForTheBook();

        }

        [When(@"click on the details on the first item available")]
        public void WhenClickOnTheDetailsOnTheFirstItemAvailable()
        {
            
            BooksPage.ClickBookDetailsLink();
        }


        [Then(@"the title of the book is ""(.*)""")]
        public void ThenTheTitleOfTheBookIs(string expectedTitle)
        {
            Assert.AreEqual(expectedTitle, BookDetailsPage.TitleIsDisplayed());
        }

        [Then(@"the type is ""(.*)""")]
        public void ThenTheTypeIs(string expectedType)
        {
            Assert.AreEqual(expectedType, BookDetailsPage.TypeIsPaperBack());
        }

        [Then(@"the price is (.*)")]
        public void ThenThePriceIs(string expectedPrice)
        {
            Assert.AreEqual(expectedPrice, BookDetailsPage.PriceIsDisplayed());
        }




    }
}
