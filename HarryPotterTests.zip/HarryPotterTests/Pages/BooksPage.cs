﻿using System;
using System.Collections.Generic;
using System.Text;
using HarryPotterTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace HarryPotterTests.Pages
{
    public class BooksPage
    {
        IWebDriver driver;
        WebDriverWait wait;

        public BooksPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebElement BooksHeader => driver.FindElement(By.XPath("//*[@id='contentGrid_313560']/div/div/div/div/div/h1"));

        public IWebElement SearchBox => driver.FindElement(By.Id("twotabsearchtextbox"));

        public IWebElement SearchIcon => driver.FindElement(By.Id("nav-search-submit-button"));

        public IWebElement BookTitle => driver.FindElement(By.XPath("//*[@id='search']/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[2]/div/div/div[1]/h2/a/span"));

        public IWebElement PaperBackType => driver.FindElement(By.XPath("//*[@id='search']/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[2]/div/div/div[3]/div[1]/div/div[1]/div[1]/a"));

        public IWebElement BookPrice => driver.FindElement(By.XPath("//*[@id='search']/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[2]/div/div/div[3]/div[1]/div/div[1]/div[2]/a/span[1]/span[2]/span[2]"));

        public IWebElement BookDetailLink => driver.FindElement(By.XPath("//*[@id='search']/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[2]/div/div/div[1]/h2/a"));
        public void WaitForTheBook()
        {
            if (wait == null)
                wait = new WebDriverWait(driver, new TimeSpan(0, 0, 10));

            //wait.Until(driver);
            wait.Until(d=> d.FindElement(By.XPath("//*[@id='search']/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div[2]/div[2]/div/div/div[1]/h2/a")).Displayed);
        }

        public bool BooksPageIsLoaded()
        {
            if (BooksHeader.Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public void EnterBookName()
        {
            SearchBox.SendKeys("Harry Potter and the Cursed Child");
        }

        public void ClickSearchIcon()
        {
            SearchIcon.Click();
        }

        public string TitleIsDisplayed()
        {
            string text;
            text = BookTitle.Text;
            return text;
        }

        public string TypeIsPaperBack()
        {
            string text;
            text = PaperBackType.Text;
            return text;
        }

        public double PriceIsDisplayed()
        {
            string text;
            text = BookPrice.Text;
            double price = double.Parse(text);
            return price;
        }

        public void ClickBookDetailsLink()
        {
            BookDetailLink.Click();
        }

       




    }
}
