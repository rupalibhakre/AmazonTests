﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarryPotterTests.Hooks;
using HarryPotterTests.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;

namespace HarryPotterTests.Steps
{
    [Binding]
    public class HomePageSteps 
    {
        private HomePage HomePage => new HomePage(SpecflowHooks.driver);




        [Given(@"the user navigates to Amazon website")]
        public void GivenTheUserNavigatesToAmazonWebsite()
        {
            HomePage.NavigateToHomePage();
        }

        [When(@"the user lands on Home Page")]
        public void WhenTheUserLandsOnHomePage()
        {
            HomePage.IsLoaded();
            HomePage.ClickAcceptLink();

        }

        [Then(@"the page is correct")]
        public void ThenThePageIsCorrect()
        {
            HomePage.SearchBarIsDisplayed();
        }


    
        

    }

    
}
