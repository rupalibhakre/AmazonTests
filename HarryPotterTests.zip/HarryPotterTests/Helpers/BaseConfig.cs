﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace HarryPotterTests.Helpers
{
    class BaseConfig
    {

        public static string AmazonUrl = ConfigurationManager.AppSettings["https://www.amazon.co.uk"];
    }
}
