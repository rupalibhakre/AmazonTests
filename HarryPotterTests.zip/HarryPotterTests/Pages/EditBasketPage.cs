﻿using System;
using System.Collections.Generic;
using System.Text;
using HarryPotterTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace HarryPotterTests.Pages
{
    public class EditBasketPage
    {
        IWebDriver driver;

        public EditBasketPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebElement BookLink => driver.FindElement(By.ClassName("a-link-normal sc-product-link"));

        public IWebElement BookTitle => driver.FindElement(By.ClassName("a-truncate-cut"));

        public IWebElement PaperBackType => driver.FindElement(By.ClassName("a-size-small sc-product-binding a-text-bold"));

        public IWebElement BookPrice => driver.FindElement(By.ClassName("a-size-medium a-color-base sc-price sc-white-space-nowrap sc-product-price a-text-bold"));

        public IWebElement Quantity => driver.FindElement(By.Id("sc-subtotal-label-activecart"));

        public IWebElement TotalPrice => driver.FindElement(By.Id("a-size-medium a-color-base sc-price sc-white-space-nowrap"));

        public bool BookIsLoaded()
        {
            if (BookLink.Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }

        }        
        
        public string BookTitleIsDisplayed()
        {
            string text;
            text = BookTitle.GetAttribute("value");
            return text;
        }

        public string TypeIsPaperBack()
        {
            string text;
            text = PaperBackType.GetAttribute("value");
            return text;
        }

        public double PriceIsDisplayed()
        {
            string text;
            text = BookPrice.GetAttribute("value");
            double price = double.Parse(text);
            return price;
        }

        public int QuantityIsDisplayed()
        {
            string text;
            text = Quantity.GetAttribute("value");
            int price = int.Parse(text);
            return price;
        }

        public double TotalPriceIsDisplayed()
        {
            string text;
            text = TotalPrice.GetAttribute("value");
            double price = double.Parse(text);
            return price;
        }



    }
}
