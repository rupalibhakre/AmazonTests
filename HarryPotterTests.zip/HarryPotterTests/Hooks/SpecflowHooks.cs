﻿using System;
using System.Collections.Generic;
using System.Text;
using BoDi;
using HarryPotterTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;

namespace HarryPotterTests.Hooks
{
    [Binding, Scope(Tag = "UI")]
    public class SpecflowHooks
    {

        public static IWebDriver driver;

        [BeforeScenario(Order = 0)]
        public void InitializeWebDriver()
        {
            if (driver == null)
            {
                driver = new ChromeDriver();
            }
            else { throw new Exception("Couldn't initialize the driver"); }
        }

        

        [AfterScenario(Order = 0)]
        public void QuitWebDriver()
        {
            if (driver != null)
            {
                driver.Quit();
            }
            else throw new Exception("There was an error while trying to close the driver");
        }
    }
}

