﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarryPotterTests.Hooks;
using HarryPotterTests.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;

namespace HarryPotterTests.Steps
{
    [Binding]
    public class EditBasketSteps
    {
        private HomePage HomePage => new HomePage(SpecflowHooks.driver);

        private BooksPage BooksPage => new BooksPage(SpecflowHooks.driver);

        private BookDetailsPage BookDetailsPage => new BookDetailsPage(SpecflowHooks.driver);

        private AddBasketPage AddBasketPage => new AddBasketPage(SpecflowHooks.driver);

        private EditBasketPage EditBasketPage => new EditBasketPage(SpecflowHooks.driver);


        [When(@"I click on the basket link")]
        public void WhenIClickOnTheBasketLink()
        {
            AddBasketPage.ClickEditBasket();
        }

        [Then(@"the book is shown on the list")]
        public void ThenTheBookIsShownOnTheList()
        {
            EditBasketPage.BookIsLoaded();
        }

        [Then(@"the title is ""(.*)""")]
        public void ThenTheTitleIs(string expectedTitle)
        {
            Assert.AreEqual(expectedTitle, EditBasketPage.BookTitleIsDisplayed());
        }

        [Then(@"the type on edit basket page is ""(.*)""")]
        public void ThenTheTypeOnEditBasketPageIs(string expectedType)
        {
            Assert.AreEqual(expectedType, EditBasketPage.TypeIsPaperBack());
        }

        [Then(@"the price on edit basket page is (.*)")]
        public void ThenThePriceOnEditBasketPageIs(double expectedPrice)
        {
            Assert.AreEqual(expectedPrice, EditBasketPage.PriceIsDisplayed());
        }

        [Then(@"the quanity on edit basket page is (.*)")]
        public void ThenTheQuanityOnEditBasketPageIs(int expectedQuantity)
        {
            Assert.AreEqual(expectedQuantity, EditBasketPage.QuantityIsDisplayed());
        }

        [Then(@"the total price is (.*)")]
        public void ThenTheTotalPriceIs(double expectedTotalPrice)
        {
            Assert.AreEqual(expectedTotalPrice, EditBasketPage.TotalPriceIsDisplayed());
        }




    }
}
