﻿using System;
using System.Collections.Generic;
using System.Text;
using HarryPotterTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace HarryPotterTests.Pages
{
    public class HomePage
    {
        IWebDriver driver;

        WebDriverWait wait;
        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebElement AmazonLogo => driver.FindElement(By.Id("nav-logo"));

        public IWebElement AcceptLink => driver.FindElement(By.Id("sp-cc-accept"));

        public IWebElement SearchBox => driver.FindElement(By.Id("twotabsearchtextbox"));

        public IWebElement BooksLink => driver.FindElement(By.XPath("/html/body/div[1]/header/div/div[4]/div[2]/div[2]/div/a[8]"));


        public HomePage NavigateToHomePage()
        {

            driver.Navigate().GoToUrl("https://amazon.co.uk");
            driver.Manage().Window.Maximize();
            return this;
        }

        public bool IsLoaded()
        {
            if (AmazonLogo.Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool SearchBarIsDisplayed()
        {
            if (SearchBox.Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public void ClickBooksLink()
        {
            if (wait == null)
            wait = new WebDriverWait(driver, new TimeSpan(0, 0, 10));

            //wait.Until(driver);
            wait.Until(d => d.FindElement(By.XPath("/html/body/div[1]/header/div/div[4]/div[2]/div[2]/div/a[8]")).Displayed);

            BooksLink.Click();

        }

        public void ClickAcceptLink()
        {
            AcceptLink.Click();
        }



    }
}
