﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace HarryPotterTests.Helpers
{
    public static class WebDriverManager
    {
        public static IWebDriver Driver { get; }

        public static void InitDriver()
        {

        }
    }
}
