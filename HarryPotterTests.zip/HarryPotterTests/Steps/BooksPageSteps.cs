﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using HarryPotterTests.Hooks;
using HarryPotterTests.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;

namespace HarryPotterTests.Steps
{
    [Binding]
    public class BooksPageSteps
    {
        private HomePage HomePage => new HomePage(SpecflowHooks.driver);

        private BooksPage BooksPage => new BooksPage(SpecflowHooks.driver);


        [When(@"they click on Books section")]
        public void WhenTheyClickOnBooksSection()
        {
            HomePage.ClickBooksLink();
        }

        [When(@"Search for the Harry Potter and the Cursed Child")]
        public void WhenSearchForTheHarryPotterAndTheCursedChild()
        {
            BooksPage.EnterBookName();
            BooksPage.ClickSearchIcon();
        }

        [Then(@"the first item has the title ""(.*)""")]
        public void ThenTheFirstItemHasTheTitle(string expectedTitle)
        {
            Assert.AreEqual(expectedTitle, BooksPage.TitleIsDisplayed());
        }

        [Then(@"selected type is ""(.*)""")]
        public void ThenSelectedTypeIs(string expectedType)
        {
            Assert.AreEqual(expectedType, BooksPage.TypeIsPaperBack());
        }


        [Then(@"the price of the book is (.*)")]
        public void ThenThePriceOfTheBookIs(double expectedPrice)
        {
            Assert.AreEqual(expectedPrice, BooksPage.PriceIsDisplayed());
        }


    }
}
